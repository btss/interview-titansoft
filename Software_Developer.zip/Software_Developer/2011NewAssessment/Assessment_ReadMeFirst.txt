Name   _________________________                     Date__________________________
1a.  Multiple by 8 without using multiplication or addition. 
Hint: Pseudo code or any language with which you are familiar are acceptable











1b. Now do the same with 7.






 

2a. Suppose you have an array of 1000 integers. The integers are in random order, but you know each of the integers is between 1 and 5000 (inclusive). In addition, each number appears only once in the array. Assume that you can access each element of the array only once. Describe an algorithm to sort it. 
Hint: Pseudo code or any language with which you are familiar are acceptable













2b. If you used auxiliary storage in your algorithm, can you find an algorithm that remains O(n) space complexity?


 








3. [C# Program] Please complete the attached file, /programming-test/c-sharp/c-sharp-test.cs. It must be executable with the requirement specified inside the code.




















4. [HTML and JavaScript] Please complete and refine the attached /programming-test/html-javascript/your-implementation.html, instruction and hints are given in the /programming-test/html-javascript/index.html 










